/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package dao;

import entity.Employee;
import entity.Project;
import entity.Task;
import exception.EmployeeNotFoundException;
import exception.ProjectNotFoundException;

/**
 *
 * @author Lenovo
 */

public interface IProjectRepository {
    boolean addEmployee(Employee emp);
    boolean addProject(Project project);
    boolean addTask(Task task);
    boolean assignProjectToEmployee(int empId, int projectId) throws EmployeeNotFoundException, ProjectNotFoundException;
    boolean assignTaskToEmployee(int empId, int taskId) throws EmployeeNotFoundException;
}
