/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;
import dao.ProjectRepositoryImpl;
import entity.Employee;
import entity.Project;
import entity.Task;
import exception.EmployeeNotFoundException;
import exception.ProjectNotFoundException;
import java.sql.Date;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ProjectRepositoryImpl repo = new ProjectRepositoryImpl();

        int choice = -1;

        while (choice != 0) {
            System.out.println("\n===== Project Management Menu =====");
            System.out.println("1. Add Employee");
            System.out.println("2. Add Project");
            System.out.println("3. Add Task");
            System.out.println("4. Assign Project to Employee");
            System.out.println("5. Assign Task within a Project to Employee");
            System.out.println("6. Delete Employee");
            System.out.println("7. Delete Task");
            System.out.println("8. List all projects assigned with tasks to an employee");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    int eid;
                    do {
                        System.out.print("Enter Employee ID: ");
                        eid = sc.nextInt();
                        sc.nextLine();
                        if (repo.employeeExists(eid)) {
                            System.out.println("Employee ID already exists. Please enter a different ID.");
                        }
                    } while (repo.employeeExists(eid));

                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Designation: ");
                    String desig = sc.nextLine();
                    System.out.print("Enter Gender: ");
                    String gender = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double sal = sc.nextDouble();
                    System.out.print("Enter Project ID: ");
                    int projectIdForEmp = sc.nextInt();
                    Employee emp = new Employee(eid, name, desig, gender, sal, projectIdForEmp);
                    System.out.println(repo.addEmployee(emp) ? "Employee added." : "Failed to add employee.");
                    break;

                case 2:
                    int pid;
                    while (true) {
                    System.out.print("Enter Project ID: ");
                    pid = sc.nextInt();
                    if (repo.projectExists(pid)) {
                        System.out.println("Project ID already exists. Please enter a different ID.");
                    } else {
                        break;
                        }
                    }
                    sc.nextLine(); // consume newline
                    System.out.print("Enter Project Name: ");
                    String pname = sc.nextLine();
                    System.out.print("Enter Description: ");
                    String desc = sc.nextLine();
                    System.out.print("Enter Start Date (yyyy-mm-dd): ");
                    String date = sc.nextLine();
                    System.out.print("Enter Status: ");
                    String status = sc.nextLine();
                    Project project = new Project(pid, pname, desc, Date.valueOf(date), status);
                    System.out.println(repo.addProject(project) ? "Project added." : "Failed to add project.");
                    break;

                    
                case 3:
                    int tid;
                    do {
                        System.out.print("Enter Task ID: ");
                        tid = sc.nextInt();
                        sc.nextLine();
                        if (repo.taskExists(tid)) {
                            System.out.println("Task ID already exists. Please enter a different ID.");
                        }
                    } while (repo.taskExists(tid));
                        
                    System.out.print("Enter Task Name: ");
                    String tname = sc.nextLine();
                    System.out.print("Enter Status: ");
                    String tstatus = sc.nextLine();
                    System.out.print("Enter Project ID: ");
                    int projId = sc.nextInt();
                    System.out.print("Enter Employee ID: ");
                    int empId = sc.nextInt();
                    Task task = new Task(tid, tname, tstatus, projId, empId);
                    System.out.println(repo.addTask(task) ? "Task added." : "Failed to add task.");
                    break;


                case 4:
                    System.out.print("Enter Employee ID: ");
                    int empIdForProject = sc.nextInt();
                    System.out.print("Enter Project ID to assign: ");
                    int projIdToAssign = sc.nextInt();
                    try {
                        boolean assigned = repo.assignProjectToEmployee(empIdForProject, projIdToAssign);
                        System.out.println(assigned ? "Project assigned to employee." : "Assignment failed.");
                    } catch (EmployeeNotFoundException | ProjectNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter Employee ID: ");
                    int empIdForTask = sc.nextInt();
                    System.out.print("Enter Task ID to assign: ");
                    int taskIdToAssign = sc.nextInt();
                    try {
                        boolean assigned = repo.assignTaskToEmployee(empIdForTask, taskIdToAssign);
                        System.out.println(assigned ? "Task assigned to employee." : "Assignment failed.");
                    } catch (EmployeeNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.print("Enter Employee ID to delete: ");
                    int empIdToDelete = sc.nextInt();
                    try {
                        boolean deleted = repo.deleteEmployee(empIdToDelete);
                        System.out.println(deleted ? "Employee deleted." : "Failed to delete employee.");
                    } catch (EmployeeNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 7:
                    System.out.print("Enter Task ID to delete: ");
                    int taskIdToDelete = sc.nextInt();
                    System.out.println(repo.deleteTask(taskIdToDelete)
                            ? "Task deleted." : "Failed to delete task.");
                    break;

                case 8:
                    System.out.print("Enter Employee ID to list tasks: ");
                    int empIdForListing = sc.nextInt();
                    try {
                        repo.getProjectsWithTasksByEmployeeId(empIdForListing);
                    } catch (EmployeeNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 9:
                    System.out.println("Exiting application.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}
