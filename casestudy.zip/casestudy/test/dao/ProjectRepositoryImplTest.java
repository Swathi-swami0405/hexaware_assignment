package dao;

import entity.Employee;
import entity.Project;
import org.junit.Test;
import static org.junit.Assert.*;

import java.sql.Date;

public class ProjectRepositoryImplTest {

    @Test
    public void testEmployeeCreation() {
        Employee emp = new Employee(1, "Test", "Tester", "Other", 1000.0, 101);
        assertNotNull(emp);
    }

    @Test
    public void testProjectCreation() {
        Project project = new Project(1, "Test Project", "Sample Desc", Date.valueOf("2024-01-01"), "New");
        assertNotNull(project);
    }

    @Test
    public void testSearchFunctionality() {
        String taskTitle = "Task A";
        assertTrue(taskTitle.contains("Task"));
    }

    @Test
    public void testExceptionThrown() {
        try {
            throw new IllegalArgumentException("Custom exception");
        } catch (IllegalArgumentException e) {
            assertEquals("Custom exception", e.getMessage());
        }
    }
}
