/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mainmod;

import dao.CodeImpl;
import entity.Policies;
import exception.PolicyNotFoundException;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CodeImpl service = new CodeImpl();
        int choice = -1;

        while (choice != 0) {
            System.out.println("\n====== Policy Management Menu ======");
            System.out.println("1. Create Policy");
            System.out.println("2. View Policy by ID");
            System.out.println("3. View All Policies");
            System.out.println("4. Update Policy");
            System.out.println("5. Delete Policy");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Policy ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Policy Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Policy Type: ");
                    String type = sc.nextLine();
                    System.out.print("Enter Coverage Amount: ");
                    double coverage = sc.nextDouble();

                    Policies newPolicy = new Policies(id, name, type, coverage);
                    boolean added = service.createPolicy(newPolicy);
                    System.out.println(added ? "Policy created successfully." : "Failed to create policy.");
                    break;

                case 2:
                    System.out.print("Enter Policy ID to view: ");
                    int viewId = sc.nextInt();
                    try {
                        Policies policy = service.getPolicy(viewId);
                        System.out.println("\n--- Policy Details ---");
                        System.out.println("ID: " + policy.getPolicyId());
                        System.out.println("Name: " + policy.getPolicyName());
                        System.out.println("Type: " + policy.getPolicyType());
                        System.out.println("Coverage: " + policy.getCoverageAmount());
                    } catch (PolicyNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 3:
                    List<Policies> list = service.getAllPolicies();
                    System.out.println("\n--- All Policies ---");
                    for (Policies p : list) {
                        System.out.println("ID: " + p.getPolicyId() +
                                           ", Name: " + p.getPolicyName() +
                                           ", Type: " + p.getPolicyType() +
                                           ", Coverage: " + p.getCoverageAmount());
                    }
                    break;

                case 4:
                    System.out.print("Enter Policy ID to update: ");
                    int updateId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Policy Name: ");
                    String newName = sc.nextLine();
                    System.out.print("Enter New Policy Type: ");
                    String newType = sc.nextLine();
                    System.out.print("Enter New Coverage Amount: ");
                    double newCoverage = sc.nextDouble();

                    Policies updatedPolicy = new Policies(updateId, newName, newType, newCoverage);
                    try {
                        boolean updated = service.updatePolicy(updatedPolicy);
                        System.out.println(updated ? "Policy updated successfully." : "Update failed.");
                    } catch (PolicyNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter Policy ID to delete: ");
                    int deleteId = sc.nextInt();
                    try {
                        boolean deleted = service.deletePolicy(deleteId);
                        System.out.println(deleted ? "Policy deleted successfully." : "Delete failed.");
                    } catch (PolicyNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.println("Exiting Policy Management System.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}
