package dao;

import entity.Policies;
import exception.PolicyNotFoundException;
import util.DBConn;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CodeImpl implements CodeInterface {
    private Connection conn;

    public CodeImpl() {
        conn = DBConn.getConnection(); 
    }

    @Override
    public boolean createPolicy(Policies policy) {
        String sql = "INSERT INTO policies (policyId, policyName, coverageAmount, policyType) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, policy.getPolicyId());
            pstmt.setString(2, policy.getPolicyName());
            pstmt.setDouble(3, policy.getCoverageAmount());
            pstmt.setString(4, policy.getPolicyType());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error in createPolicy: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Policies getPolicy(int policyId) throws PolicyNotFoundException {
        String sql = "SELECT * FROM policies WHERE policyId = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, policyId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Policies(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getString("policyType"),
                    rs.getDouble("coverageAmount")
                );
            } else {
                throw new PolicyNotFoundException("Policy ID " + policyId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error in getPolicy: " + e.getMessage());
            return null;
        }
    }

    @Override
    public List<Policies> getAllPolicies() {
        String sql = "SELECT * FROM policies";
        List<Policies> policyList = new ArrayList<>();
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Policies policy = new Policies(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getString("policyType"),
                    rs.getDouble("coverageAmount")
                );
                policyList.add(policy);
            }
        } catch (SQLException e) {
            System.out.println("Error in getAllPolicies: " + e.getMessage());
        }
        return policyList;
    }

    @Override
    public boolean updatePolicy(Policies policy) throws PolicyNotFoundException {
        // Check if policy exists
        getPolicy(policy.getPolicyId());

        String sql = "UPDATE policies SET policyName = ?, coverageAmount = ?, policyType = ? WHERE policyId = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, policy.getPolicyName());
            pstmt.setDouble(2, policy.getCoverageAmount());
            pstmt.setString(3, policy.getPolicyType());
            pstmt.setInt(4, policy.getPolicyId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error in updatePolicy: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deletePolicy(int policyId) throws PolicyNotFoundException {
        // Check if policy exists
        getPolicy(policyId);

        String sql = "DELETE FROM policies WHERE policyId = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, policyId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error in deletePolicy: " + e.getMessage());
            return false;
        }
    }
}
