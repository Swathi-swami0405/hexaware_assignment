
package dao;

import entity.Policies;
import exception.PolicyNotFoundException;

import java.util.List;

public interface CodeInterface {
    boolean createPolicy(Policies policy);
    Policies getPolicy(int policyId) throws PolicyNotFoundException;
    List<Policies> getAllPolicies();
    boolean updatePolicy(Policies policy) throws PolicyNotFoundException;
    boolean deletePolicy(int policyId) throws PolicyNotFoundException;
}
