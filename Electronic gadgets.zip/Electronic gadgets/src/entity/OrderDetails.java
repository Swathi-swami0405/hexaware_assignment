package entity;

public class OrderDetails {
    private int orderDetailID;
    private Orders order;
    private Products product;
    private int quantity;

    public OrderDetails(int orderDetailID, Orders order, Products product, int quantity) {
        this.orderDetailID = orderDetailID;
        this.order = order;
        this.product = product;
        setQuantity(quantity);
    }

    public int getOrderDetailID() {
        return orderDetailID;
    }

    public Orders getOrder() {
        return order;
    }

    public Products getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than 0.");
        }
        this.quantity = quantity;
    }
}