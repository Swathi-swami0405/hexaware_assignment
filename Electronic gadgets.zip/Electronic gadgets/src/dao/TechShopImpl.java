package dao;

import entity.*;
import exception.*;
import util.DBConnUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TechShopImpl implements TechShopInterface {

    private Connection conn;

    public TechShopImpl() {
        conn = DBConnUtil.getConnection();
    }

    @Override
    public boolean registerCustomer(Customers customer) throws InvalidDataException {
        if (conn == null) return false;

        String query = "INSERT INTO customers (customerid, firstname, lastname, email, phone, address) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, customer.getCustomerID());
            ps.setString(2, customer.getFirstName());
            ps.setString(3, customer.getLastName());
            ps.setString(4, customer.getEmail());
            ps.setString(5, customer.getPhone());
            ps.setString(6, customer.getAddress());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            if (e.getMessage().contains("duplicate")) {
                throw new InvalidDataException("Email already exists.");
            }
            System.out.println("registerCustomer(): " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean addOrUpdateProduct(Products product) {
        String query = """
                INSERT INTO products (productid, productname, description, price, category)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    productname = VALUES(productname),
                    description = VALUES(description),
                    price = VALUES(price),
                    category = VALUES(category)
                """;

        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, product.getProductID());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setString(5, product.getCategory());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("addOrUpdateProduct(): " + e.getMessage());
            return false;
        }
    }


    @Override
    public boolean removeProduct(int productId) {
        String query = "DELETE FROM products WHERE productid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, productId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("removeProduct(): " + e.getMessage());
            return false;
        }
    }

    @Override
    public Products getProductById(int productId) {
        String query = "SELECT * FROM products WHERE productid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Products(
                    rs.getInt("productid"),
                    rs.getString("productname"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category")
                );
            }
        } catch (SQLException e) {
            System.out.println("getProductById(): " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Products> getAllProducts() {
        List<Products> products = new ArrayList<>();
        String query = "SELECT * FROM products";
        try (PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                products.add(new Products(
                    rs.getInt("productid"),
                    rs.getString("productname"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category")
                ));
            }
        } catch (SQLException e) {
            System.out.println("getAllProducts(): " + e.getMessage());
        }
        return products;
    }

    @Override
    public boolean placeOrder(Orders order, List<OrderDetails> details)
            throws InsufficientStockException, IncompleteOrderException {

        if (order == null || order.getCustomer() == null || details == null || details.isEmpty()) {
            throw new IncompleteOrderException("Order, customer, or order details are incomplete.");
        }

        String orderQuery = "INSERT INTO orders (orderid, customerid, orderdate, totalamount, status) VALUES (?, ?, ?, ?, ?)";
        String detailsQuery = "INSERT INTO orderdetails (orderdetailid, orderid, productid, quantity) VALUES (?, ?, ?, ?)";
        String inventoryQuery = "UPDATE inventory SET quantityinstock = quantityinstock - ? WHERE productid = ?";

        try {
            conn.setAutoCommit(false);

            // Insert into orders
            try (PreparedStatement psOrder = conn.prepareStatement(orderQuery)) {
                psOrder.setInt(1, order.getOrderID());
                psOrder.setInt(2, order.getCustomer().getCustomerID());
                psOrder.setTimestamp(3, Timestamp.valueOf(order.getOrderDate()));
                psOrder.setDouble(4, order.getTotalAmount());
                psOrder.setString(5, order.getStatus());
                psOrder.executeUpdate();
            }

            for (OrderDetails detail : details) {
                int productId = detail.getProduct().getProductID();
                int quantity = detail.getQuantity();

                // Check stock
                Inventory inv = getInventoryByProductId(productId);
                if (inv == null) {
                    throw new IncompleteOrderException("Inventory not found for product ID: " + productId);
                }
                if (inv.getQuantityInStock() < quantity) {
                    throw new InsufficientStockException("Not enough stock for product ID: " + productId);
                }

                // Insert into orderdetails
                try (PreparedStatement psDetail = conn.prepareStatement(detailsQuery)) {
                    psDetail.setInt(1, detail.getOrderDetailID());
                    psDetail.setInt(2, order.getOrderID());
                    psDetail.setInt(3, productId);
                    psDetail.setInt(4, quantity);
                    psDetail.executeUpdate();
                }

                // Update inventory
                try (PreparedStatement psInventory = conn.prepareStatement(inventoryQuery)) {
                    psInventory.setInt(1, quantity);
                    psInventory.setInt(2, productId);
                    psInventory.executeUpdate();
                }
            }

            conn.commit();
            return true;

        } catch (Exception e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.out.println("Rollback failed: " + rollbackEx.getMessage());
            }
            System.out.println("placeOrder() failed: " + e.getMessage());
            return false;
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Auto-commit reset failed: " + e.getMessage());
            }
        }
    }


    @Override
    public String getOrderStatus(int orderId) {
        String query = "SELECT status FROM orders WHERE orderid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("status");
        } catch (SQLException e) {
            System.out.println("getOrderStatus(): " + e.getMessage());
        }
        return "Order not found";
    }

    @Override
    public boolean updateInventory(int productId, int quantity) {
        String query = "UPDATE inventory SET quantityinstock = ? WHERE productid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, quantity);
            ps.setInt(2, productId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("updateInventory(): " + e.getMessage());
            return false;
        }
    }

    @Override
    public Inventory getInventoryByProductId(int productId) {
        String query = "SELECT * FROM inventory WHERE productid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Inventory(
                    rs.getInt("inventoryid"),
                    getProductById(productId),
                    rs.getInt("quantityinstock"),
                    rs.getTimestamp("laststockupdate").toLocalDateTime()
                );
            }
        } catch (SQLException e) {
            System.out.println("getInventoryByProductId(): " + e.getMessage());
        }
        return null;
    }

    @Override
    public double getTotalSales() {
        String query = "SELECT SUM(totalamount) AS totalsales FROM orders";
        try (PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble("totalsales");
        } catch (SQLException e) {
            System.out.println("getTotalSales(): " + e.getMessage());
        }
        return 0.0;
    }

    @Override
    public boolean updateCustomerInfo(Customers customer) throws InvalidDataException {
        String query = "UPDATE customers SET firstname = ?, lastname = ?, email = ?, phone = ?, address = ? WHERE customerid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, customer.getFirstName());
            ps.setString(2, customer.getLastName());
            ps.setString(3, customer.getEmail());
            ps.setString(4, customer.getPhone());
            ps.setString(5, customer.getAddress());
            ps.setInt(6, customer.getCustomerID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new InvalidDataException("Update failed: " + e.getMessage());
        }
    }

    @Override
    public boolean processPayment(int orderId, double amount, String method) throws PaymentFailedException {
        // Simulate payment
        if (amount <= 0) throw new PaymentFailedException("Invalid payment amount.");
        // In real-world, payment gateway logic goes here.
        return true;
    }

    @Override
    public List<Products> searchProducts(String keyword) {
        List<Products> products = new ArrayList<>();
        String query = "SELECT * FROM products WHERE LOWER(productname) LIKE ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, "%" + keyword.toLowerCase() + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                products.add(new Products(
                    rs.getInt("productid"),
                    rs.getString("productname"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category")
                ));
            }
        } catch (SQLException e) {
            System.out.println("searchProducts(): " + e.getMessage());
        }
        return products;
    }
    @Override
    public int getInventoryQuantity(int productId) {
        String query = "SELECT quantityinstock FROM inventory WHERE productid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("quantityinstock");
            }
        } catch (SQLException e) {
            System.out.println("getInventoryQuantity(): " + e.getMessage());
        }
        return 0;
    }

    @Override
    public boolean updateInventoryQuantity(int productId, int newQuantity) {
        String query = "UPDATE inventory SET quantityinstock = ?, laststockupdate = ? WHERE productid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, newQuantity);
            ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now())); // updating the last stock update time
            ps.setInt(3, productId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("updateInventoryQuantity(): " + e.getMessage());
        }
        return false;
    }
    @Override
    public Customers getCustomerById(int customerId) {
        String query = "SELECT * FROM customers WHERE customerid = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Customers(
                    rs.getInt("customerid"),
                    rs.getString("firstname"),
                    rs.getString("lastname"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("address")
                );
            }
        } catch (SQLException e) {
            System.out.println("getCustomerById(): " + e.getMessage());
        }
        return null;
    }

    

}