package util;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String fileName) {
        try (FileReader reader = new FileReader(fileName)) {
            Properties props = new Properties();
            props.load(reader);

            String host = props.getProperty("host");
            String dbname = props.getProperty("dbname");
            String port = props.getProperty("port");
            String user = props.getProperty("user");
            String password = props.getProperty("password");

            return "jdbc:mysql://" + host + ":" + port + "/" + dbname + "?user=" + user + "&password=" + password;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
