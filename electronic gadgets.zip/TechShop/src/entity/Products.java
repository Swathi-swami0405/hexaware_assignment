package entity;

public class Products {
    private int productID;
    private String productName;
    private String description;
    private double price;
    private String category;

    public Products(int productID, String productName, String description, double price, String category) {
        this.productID = productID;
        this.productName = productName;
        this.description = description;
        setPrice(price);
        this.category = category;
    }

    public int getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price must be non-negative.");
        }
        this.price = price;
    }

    public String getCategory() {
        return category;
    }
}
