package entity;

import java.time.LocalDateTime;

public class Orders {
    private int orderID;
    private Customers customer;
    private LocalDateTime orderDate;
    private double totalAmount;
    private String status;

    public Orders(int orderID, Customers customer, LocalDateTime orderDate, double totalAmount, String status) {
        this.orderID = orderID;
        this.customer = customer;
        this.orderDate = orderDate;
        setTotalAmount(totalAmount);
        this.status = status;
    }

    public int getOrderID() {
        return orderID;
    }

    public Customers getCustomer() {
        return customer;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        if (totalAmount < 0) {
            throw new IllegalArgumentException("Total amount must be non-negative.");
        }
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
