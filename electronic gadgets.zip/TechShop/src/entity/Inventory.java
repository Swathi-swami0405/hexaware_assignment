package entity;

import java.time.LocalDateTime;

public class Inventory {
    private int inventoryID;
    private Products product;
    private int quantityInStock;
    private LocalDateTime lastStockUpdate;

    public Inventory(int inventoryID, Products product, int quantityInStock, LocalDateTime lastStockUpdate) {
        this.inventoryID = inventoryID;
        this.product = product;
        setQuantityInStock(quantityInStock);
        this.lastStockUpdate = lastStockUpdate;
    }

    public int getInventoryID() {
        return inventoryID;
    }

    public Products getProduct() {
        return product;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(int quantityInStock) {
        if (quantityInStock < 0) {
            throw new IllegalArgumentException("Quantity in stock must be non-negative.");
        }
        this.quantityInStock = quantityInStock;
    }

    public LocalDateTime getLastStockUpdate() {
        return lastStockUpdate;
    }

    public void setLastStockUpdate(LocalDateTime lastStockUpdate) {
        this.lastStockUpdate = lastStockUpdate;
    }
}
