package dao;

import entity.Customers;
import entity.Products;
import entity.Orders;
import entity.Inventory;
import entity.OrderDetails;
import exception.*;

import java.util.List;

public interface TechShopInterface {

    // 1. Customer Registration
    boolean registerCustomer(Customers customer) throws InvalidDataException;

    // 2. Product Catalog Management
    boolean addOrUpdateProduct(Products product);
    boolean removeProduct(int productId);
    Products getProductById(int productId);
    List<Products> getAllProducts();

    // 3. Placing Customer Orders
    boolean placeOrder(Orders order, List<OrderDetails> details)
        throws InsufficientStockException, IncompleteOrderException;

    // 4. Tracking Order Status
    String getOrderStatus(int orderId);

    // 5. Inventory Management
    boolean updateInventory(int productId, int quantity);
    Inventory getInventoryByProductId(int productId);

    // 6. Sales Reporting
    double getTotalSales();

    // 7. Customer Account Updates
    boolean updateCustomerInfo(Customers customer) throws InvalidDataException;

    // 8. Payment Processing
    boolean processPayment(int orderId, double amount, String method)
        throws PaymentFailedException;

    // 9. Product Search
    List<Products> searchProducts(String keyword);
}
