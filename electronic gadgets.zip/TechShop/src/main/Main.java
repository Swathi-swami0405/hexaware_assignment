package main;

import dao.TechShopImpl;
import entity.*;
import exception.*;

import java.time.LocalDateTime;
import java.util.*;

public class Main {

    static Scanner scanner = new Scanner(System.in);
    static TechShopImpl techShop = new TechShopImpl();

    public static void main(String[] args) {
        int choice;
        do {
            printMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> registerCustomer();
                case 2 -> addOrUpdateProduct();
                case 3 -> placeOrder();
                case 4 -> getOrderStatus();
                case 5 -> viewAllProducts();
                case 6 -> updateInventory();
                case 7 -> updateCustomerInfo();
                case 8 -> searchProduct();
                case 9 -> showTotalSales();
                case 0 -> System.out.println("Exiting application. Goodbye!");
                default -> System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 0);
    }

    static void printMenu() {
        System.out.println("\n=== TECH SHOP MENU ===");
        System.out.println("1. Register Customer");
        System.out.println("2. Add or Update Product");
        System.out.println("3. Place Order");
        System.out.println("4. Check Order Status");
        System.out.println("5. View All Products");
        System.out.println("6. Update Inventory");
        System.out.println("7. Update Customer Info");
        System.out.println("8. Search Products");
        System.out.println("9. Show Total Sales");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    static void registerCustomer() {
        try {
            System.out.print("Customer ID: ");
            int id = scanner.nextInt(); scanner.nextLine();
            System.out.print("First Name: ");
            String fn = scanner.nextLine();
            System.out.print("Last Name: ");
            String ln = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Phone: ");
            String phone = scanner.nextLine();
            System.out.print("Address: ");
            String address = scanner.nextLine();

            Customers customer = new Customers(id, fn, ln, email, phone, address);
            boolean success = techShop.registerCustomer(customer);
            System.out.println(success ? "Customer registered successfully." : "Registration failed.");
        } catch (InvalidDataException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    static void addOrUpdateProduct() {
        System.out.print("Product ID: ");
        int id = scanner.nextInt(); scanner.nextLine();
        System.out.print("Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Description: ");
        String desc = scanner.nextLine();
        System.out.print("Price: ");
        double price = scanner.nextDouble(); scanner.nextLine();
        System.out.print("Category: ");
        String cat = scanner.nextLine();

        Products product = new Products(id, name, desc, price, cat);
        boolean success = techShop.addOrUpdateProduct(product);
        System.out.println(success ? "Product added/updated successfully." : "Operation failed.");
    }

    static void placeOrder() {
        try {
            System.out.print("Order ID: ");
            int oid = scanner.nextInt(); scanner.nextLine();
            System.out.print("Customer ID: ");
            int cid = scanner.nextInt(); scanner.nextLine();
            System.out.print("Total Amount: ");
            double total = scanner.nextDouble(); scanner.nextLine();
            Customers customer = new Customers(cid, "", "", "", "", ""); 
            Orders order = new Orders(oid, customer, LocalDateTime.now(), total, "PLACED");

            System.out.print("How many products in this order? ");
            int n = scanner.nextInt(); scanner.nextLine();
            List<OrderDetails> details = new ArrayList<>();

            for (int i = 0; i < n; i++) {
                System.out.print("Order Detail ID: ");
                int odid = scanner.nextInt(); scanner.nextLine();
                System.out.print("Product ID: ");
                int pid = scanner.nextInt(); scanner.nextLine();
                System.out.print("Quantity: ");
                int qty = scanner.nextInt(); scanner.nextLine();

                Products product = new Products(pid, "", "", 0.0, ""); // minimal dummy
                OrderDetails detail = new OrderDetails(odid, order, product, qty);
                details.add(detail);
            }

            boolean placed = techShop.placeOrder(order, details);
            System.out.println(placed ? "Order placed successfully." : "Failed to place order.");

        } catch (Exception e) {
            System.out.println("Order error: " + e.getMessage());
        }
    }

    static void getOrderStatus() {
        System.out.print("Enter Order ID: ");
        int id = scanner.nextInt(); scanner.nextLine();
        String status = techShop.getOrderStatus(id);
        System.out.println("Order Status: " + status);
    }

    static void viewAllProducts() {
        List<Products> products = techShop.getAllProducts();
        System.out.println("--- Product List ---");
        for (Products p : products) {
            System.out.println(p);
        }
    }

static void updateInventory() {
    System.out.print("Product ID: ");
    int productId = scanner.nextInt(); scanner.nextLine();
    System.out.print("New Quantity in Stock: ");
    int quantity = scanner.nextInt(); scanner.nextLine();

    boolean updated = techShop.updateInventory(productId, quantity);
    System.out.println(updated ? "Inventory updated successfully." : "Failed to update inventory.");
}


    static void viewInventory() {
        System.out.print("Product ID: ");
        int pid = scanner.nextInt(); scanner.nextLine();
        Inventory inv = techShop.getInventoryByProductId(pid);
        System.out.println(inv != null ? inv : "Inventory not found.");
    }

    static void updateCustomerInfo() {
        try {
            System.out.print("Customer ID: ");
            int id = scanner.nextInt(); scanner.nextLine();
            System.out.print("First Name: ");
            String fn = scanner.nextLine();
            System.out.print("Last Name: ");
            String ln = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Phone: ");
            String phone = scanner.nextLine();
            System.out.print("Address: ");
            String address = scanner.nextLine();

            Customers customer = new Customers(id, fn, ln, email, phone, address);
            boolean updated = techShop.updateCustomerInfo(customer);
            System.out.println(updated ? "Customer info updated." : "Update failed.");
        } catch (InvalidDataException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    static void searchProduct() {
        System.out.print("Enter keyword to search: ");
        String keyword = scanner.nextLine();
        List<Products> results = techShop.searchProducts(keyword);
        if (results.isEmpty()) {
            System.out.println("No products found.");
        } else {
            results.forEach(System.out::println);
        }
    }

    static void showTotalSales() {
        double total = techShop.getTotalSales();
        System.out.printf("Total Sales: ₹%.2f\n", total);
    }
}
